#/usr/bin/bash
#title : VnomNetwork
#AUTHOR : By Davistar
clear
echo -e "\033[3;31m ..........................."
echo -e "\033[6;31m Loading ........"
read -t 1
echo -e "\033[6;31m Loading ........"
read -t 1
echo -e "\033[6;31m Loading ........"
figlet VnomNetwork...
read -t 1
chmod +x VnomMain.sh
clear
./VnomMain.sh

