from core import colors

version = "3.1-alpha"
apiversion = "1.0.1-alpha"
update_date = "3.1.2017"
codename = "uranium"

about = ("Hakku Framework "+version+" "+codename+
"\nauthor: Noa-Emil Nissinen (4shadoww)"
"\nemail: 4shadoww0@gmail.com"
"\ngithub: 4shadoww")