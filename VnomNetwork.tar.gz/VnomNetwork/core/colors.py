#        Copyright (C) 2015 Noa-Emil Nissinen (4shadoww)

purple = '\033[95m'
blue = '\033[94m'
green = '\033[32m'
cyan = '\033[36m'
yellow = '\033[93m'
red = '\033[91m'
end = '\033[0m'
bold = '\033[1m'
uline = '\033[4m'