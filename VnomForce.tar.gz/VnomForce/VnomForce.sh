#/usr/bin/bash
clear
echo -e "\033[31m..............................................."
figlet VnomForce
echo -e "\033[34m Created By Davistar"
echo -e "\033[31m..............................................."
PS3="choose options>>> "
    select choix in \
       "launch hydra in terminal" \
       "launch hydra GTK" \
       "launch crunch generator wordlist" \
       "launch Pulse Cracker facebook,instagram,twitter" \
       "launch Brut3k1t" \
       "launch hydra wizzard" \
       "exit"
     do
       case $REPLY in
          1) hydra  ;;
          2) hydra-gtk  ;;
          3) crunch ;;
          4) ./p.sh ;;
          5) ./b.sh ;;
          6) hydra-wizard ;;
          ?) echo "return principale Menu"
             break ;;
          *) echo "options not valid !!!" ;;
       esac
   exit
done
