#/usr/bin/bash
cd tools
cd Pulse
chmod +x pulse.py
python pulse.py -h
