#/usr/bin/bash
cd tools
cd brutekit
chmod +x brut3k1t
./brut3k1t
