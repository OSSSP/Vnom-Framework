#/usr/bin/bash
clear
echo -e "\033[32mInstallation du setup"
echo -e "\033[31mScript Created By Davistar"
read -t 2
apt update && apt upgrade
clear
apt install hydra crunch git
read -t 2
screenfetch
read -t 2
mkdir tools
cd tools
git clone https://github.com/Ethical-H4CK3R/Pulse
git clone https://github.com/ex0dus-0x/brut3k1t
mv brut3k1t brutekit
chmod +x installer
./installer
apt install python python-pip python2.7 python-all-dev
pip install -r requirements.txt
read -t 2
echo -e "\033[32m Installation du pack VnomForce Successfully"
exit
