#/usr/bin/bash
clear
echo -e "\033[31m Uninstalling running wait moment please........"
read -t 3
rm -r tools
echo -e "\033[32m Script Uninstalling succesfully"
exit

