#/usr/bin/bash
cd tools
cd EV
./evil-droid
