#/usr/bin/bash
cd ..
chmod +x Vnom
./Vnom
