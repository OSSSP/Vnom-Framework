#/usr/bin/bash
cd tools
cd Brutal
chmod +x Brutal.sh
./Brutal.sh

