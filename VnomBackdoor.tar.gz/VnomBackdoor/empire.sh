#/usr/bin/bash
cd tools
cd empire
./empire

