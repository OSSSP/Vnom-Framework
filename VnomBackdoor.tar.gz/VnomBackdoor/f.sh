#/usr/bin/bash
cd tools
cd TFR
chmod +x fatrat
./fatrat
