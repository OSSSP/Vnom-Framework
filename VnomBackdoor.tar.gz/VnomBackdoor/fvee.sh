#/usr/bin/bash
echo -e "\033[31m Install or Update package tools"
screenfetch
apt update
apt install git curl clang
mkdir tools
cd tools
git clone https://github.com/Screetsec/TheFatRat
mv TheFatRat TFR
cd TFR
chmod +x setup.sh
./setup.sh
chmod +x update
./update
cd ../
git clone https://github.com/Veil-Framework/Veil-Evasion
mv Veil-Evasion Veil
cd Veil
cd setup
chmod +x setup.sh
./setup.sh
cd ../
cd ../
git clone https://github.com/M4sc3r4n0/Evil-Droid
mv Evil-Droid EV
cd EV
chmod +x evil-droid
cd ../
git clone https://github.com/Screetsec/Brutal
cd Brutal
chmod +x Brutal.sh
cd ../
apt install set
git clone https://github.com/EmpireProject/Empire
mv Empire empire
cd empire
cd setup
chmod +x install.sh
./install.sh
cd ../
echo -e "\033[32m Setup Is Installed succesfully"
echo -e "\033[31m Check for Update"
read -t 1
apt update
apt upgrade

