#/usr/bin/bash
#title: VnomBackdoor
clear
echo -e "\033[31m..............................."
echo -e "\033[35mChecking os system"
screenfetch
read -t 2
apt update && apt upgrade
read -t 2
echo -e "\033[31mUpdating Successfully"
read -t 1
echo -e "\033[32mInstalling Rat Tools"
apt install metasploit-framework msfpc git curl python python3 python2.7
echo -e "\033[32mMetasploit Installed Successfully"
echo -e "\033[34m Installation de Thfatrat Veil-Evasion Evil-Droid empire etc..."
read -t 2
chmod +x fvee.sh
./fvee.sh

