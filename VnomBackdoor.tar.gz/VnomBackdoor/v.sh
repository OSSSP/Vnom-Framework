#/usr/bin/bash
cd tools
cd Veil
python Veil-Evasion.py

