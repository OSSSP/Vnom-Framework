#/usr/bin/bash
clear
echo -e "\033[31m.................................................................."
figlet VnomBackdoor
echo -e "\033[31m This Tools menue for Pentesting"
echo -e "\033[32m Created By Davistar"
echo -e "\033[35m ......................................."
PS3="choose options>>> "
    select choix in \
       "launch msfconsole" \
       "launch TheFatRat" \
       "launch Brutal" \
       "launch Evil-Droid" \
       "launch Empire" \
       "launch setoolkit" \
       "launch msfVenom" \
       "launch Msf payload creator" \
       "launch Veil-Evasion" \
       "return menu"
     do
       case $REPLY in
          1) msfconsole  ;;
          2) ./f.sh  ;;
          3) ./b.sh ;;
          4) ./ev.sh ;;
          5) ./empire.sh ;;
          6) setoolkit ;;
          7) msfvenom ;;
          8) msfpc ;;
          9) ./v.sh ;;
          10) echo "return principale menu"
             break ;;
          *) echo "options not valid !!!" ;;
       esac
   exit
 ./turn.sh
done
