#/usr/bin/bash
clear
echo -e "\033[35m.........................................."
figlet VnomMap
echo -e "\033[38m Created By Davistar"
PS3="choose options>>> "
    select choix in \
       "launch SQLMAP" \
       "launch HQLMAP" \
       "beef" \
       "beef-xss" \
       "exit"
     do
       case $REPLY in
          1) sqlmap  ;;
          2) ./hqlmap  ;;
          3) beef ;;
          4) beef-xss ;;
          5) echo "exit....."
             break ;;
          *) echo "options not valid !!!" ;;
       esac
   exit
done
