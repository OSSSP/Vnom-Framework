#/usr/bin/bash
echo -e "\033[31mWelcome to the setup VnomMap"
echo -e "\033[32m VnomMap is exploitation Database"
read -t 3
echo -e "\033[35m Checking os......."
read -t 2
screenfetch
echo -e "\033[31m Os is valided"
echo -e "\033[31m OS compatible Vnom-Os Black-Arch Debian Ubuntu Termux Kali-Linux"
read -t 2
apt install sqlmap git curl beef beef-xss fruitywifi-module-beef mitmf ruby-beefcake python python2.7 python3 python-all-dev
apt update && apt upgrade
read -t 2
clear
echo -e "\033[32m SETUP Is Installed succesfully"
read -t 1
mkdir tools
cd tools
git clone https://github.com/PaulSec/HQLmap
mv HQLmap hqlmap
read -t 1
echo -e "\033[34m Setup is Installed Successfully"
clear
exit
